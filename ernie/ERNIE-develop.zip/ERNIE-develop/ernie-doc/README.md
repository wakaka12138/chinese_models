```bash
 _____ ____  _   _ ___ _____      ______   _____    _____
| ____|  _ \| \ | |_ _| ____|    |  __  \/  ___  \/  ____|
|  _| | |_) |  \| || ||  _| _____| |  \  | |   | | /   
| |___|  _ <| |\  || || |__|_____| |__/  | |___| | \ ____  
|_____|_| \_\_| \_|___|_____|    |______/\ _____ /\ _____|
```

The `ERNIE-Doc` (including all our pre-trained models) has been released at [here](https://github.com/PaddlePaddle/ERNIE/tree/repro/ernie-doc).
