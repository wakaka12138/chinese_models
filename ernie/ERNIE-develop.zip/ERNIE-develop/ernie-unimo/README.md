The `ERNIE-UNIMO` (including all our pre-trained models) has been released at [here](https://github.com/PaddlePaddle/ERNIE/tree/repro/ernie-unimo).
